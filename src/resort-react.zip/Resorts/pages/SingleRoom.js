import React from 'react';
const  SingleRoom = ()=> {
  return (
    <div className="single-room-app">
<h3>SingleRoom</h3>
    </div>

  )
}

export default SingleRoom;
